<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "website";
//create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// check connection
if($conn->connect_error)

    die("connection-fail = " . $conn->connect_error);
$A = "SELECT * FROM `registration`";
$B = $conn->query($A);
?>
<html>
    <head>
        <title>Mangostore</title>
        <link rel="stylesheet" href="form.css">
        <div class="navbar">
                    <span class="home"> <a href="Index.html">HOME</a> </span>
                    <span class="about"> <a href="Aboutus.html">ABOUT</a> </span>
                   <span class="shop"> <a href="SHOP.html">SHOP</a> </span> 
                   <span class="contact"> <a href="CONTACT%20US.html">CONTACT</a> </span>
                   <span class="cart"> <a href="CART.html">CART</a> </span>
                   <span class="terms"> <a href="TERMS%20AND%20CONDITIONS.html">Terms and Condition</a> </span>
                    <span class="cart"> <a href="form.php">Sign Up</a> </span>
        <div class="logoimage"> <img class="logo"  src="images/logoPNG.png"/></div>
</div>
        <div>
               <hr style="color:white;">
        </div>
    </head>
    <body>
        <div>
            <img class="google-image" src="images/g111.png">
        </div>
    
        <div class="main">
            <h1> Sign Up</h1>
            
            <form class="form" action="Insert.php" method="post">
            <hr>
                <label>UserName</label>
                <input type="text" name="uname" placeholder="firstname" required>
                <label>User Email</label> 
                <input type="email" name="email" value="" placeholder="E-mail" required>  
                <label>Password</label>  
                <input type="password" name="password"  placeholder="password" required>  
                <label>Re-enter Password</label>  
                <input type="password" name="re-password"  placeholder="Confirm-password" required> 
                <button type="submit">Sign Up</button>
                <button type="reset">Reset</button>
                
            </form>
            
        </div>
        <h2 style="color:white; text-align:center;">DATA SHEET</h2>
        <table class="table">
            <tr>
                <td> <b>Sr.No</b> </td>
                <td> <b>ID</b></td>
                <td><b>UserName</b></td>
                <td><b>User Email</b></td>
                <td><b>Password</b></td>
                <td><b>Re-enter Password</b></td>
            </tr>
            <?php
            $i =1;
            while( $row = $B->fetch_assoc() )
            {
            ?>
            <tr>
                <td><?php echo $i; ?></td>
                <td><?php echo $row['ID'] ?></td>
                <td><?php echo $row['uname'] ?></td>
                <td><?php echo $row['email'] ?></td>
                <td><?php echo $row['password'] ?></td>
                <td><?php echo $row['re_password'] ?></td>
            </tr>
            <?php
            $i++;
            }
            ?>
        </table>
    </body>
</html>