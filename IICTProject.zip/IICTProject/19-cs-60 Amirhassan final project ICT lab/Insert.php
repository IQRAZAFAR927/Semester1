<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "website";
//create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// check connection
if($conn->connect_error)
    die("connection-fail = " . $conn->connect_error);

echo $username = $_REQUEST['uname'];
echo $Email = $_REQUEST['email'];
echo $Password = $_REQUEST['password'];
echo $Re_Password = $_REQUEST['re-password'];
$qury="INSERT INTO `registration` (`ID`, `uname`, `email`, `password`, `re_password`) VALUES (NULL, '$username', '$Email', '$Password', '$Re_Password');";

if($conn->query($qury)=== TRUE)
{
    header('location:form.php?msg.succes');
}
else
{
    echo "Error.".$sql. "<br>" . $conn->error;
}
$conn->close();
?>
<!-------------------HTML CODE------------------->
<html>
    <head>
        <title>Insert</title>
    </head>
    <body>
        <h1>Hello janab</h1>
        
    </body>
</html>